package com.mercy.encoder.input.audio;

import com.mercy.encoder.Frame;

/**
 * Created by pedro on 19/01/17.
 */

public interface GetMicrophoneData {

  void inputPCMData(Frame frame);
}
