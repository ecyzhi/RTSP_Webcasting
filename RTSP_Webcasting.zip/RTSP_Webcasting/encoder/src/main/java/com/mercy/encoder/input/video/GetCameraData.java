package com.mercy.encoder.input.video;

import com.mercy.encoder.Frame;

/**
 * Created by pedro on 20/01/17.
 */

public interface GetCameraData {

  void inputYUVData(Frame frame);
}
