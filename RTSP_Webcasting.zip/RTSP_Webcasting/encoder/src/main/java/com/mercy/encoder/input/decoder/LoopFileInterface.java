package com.mercy.encoder.input.decoder;

/**
 * Created by pedro on 4/03/18.
 */

public interface LoopFileInterface {

  void onReset(boolean isVideo);
}
