package com.mercy.encoder.input.video;

/**
 * Created by pedro on 12/04/17.
 */

public class CameraOpenException extends RuntimeException {

  public CameraOpenException(String message) {
    super(message);
  }
}
