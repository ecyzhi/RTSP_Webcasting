package com.mercy.vlc;

/**
 * Created by pedro on 29/06/17.
 */

public class Constants {
  public static final int BUFFER = 1000; //buffer in ms
}
